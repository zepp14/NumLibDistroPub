import time
NumeralCounter = 0
import numpy as np
import matplotlib
from scipy.optimize import minimize
from scipy import optimize
from scipy.special import perm

from sklearn.cluster import KMeans

import itertools

import matplotlib.pyplot as plt
#matplotlib.pygui(true)
print(matplotlib.is_interactive())

import platform
print(platform.python_version(), "Cool")
#import zeppNumLib


import sdmiFuncLib as sfl
import os




################### Generate Dataset ###################################
NoInv = 4
NoSamp = 25
dataSetName = "/Datasets/Dataset_4I_v1.npy"
typeEff = 0
numberOfIter = 0
Error = []
data = []

cur_path = os.path.dirname(__file__)

new_path = cur_path +dataSetName 
print(cur_path +dataSetName )

while numberOfIter <= NoSamp:
    print(numberOfIter)
    numberOfIter= numberOfIter+1
# TESTING ALGORITHM
    r =0
    alph = 3.5
    Def = [0, 0]
    G_circ = [0, -8,  8]

#generate invaders
    numOfInv = (NoInv,2)

    randoNum = np.random.random_sample(numOfInv)

    xBound=[-15,15]
    yBound=[2,25]
    I_array = np.zeros(numOfInv)

    for i, num in enumerate(randoNum):
        I_array[i,0] = xBound[1]*2*num[0] + xBound[0] 
        I_array[i,1] = ((yBound[1]-yBound[0] ))*(num[1]) + yBound[0] 

    #print(I_array)
    I_dict, I_list = sfl.createInvDict(I_array)
#Enumeration
    sfl.NumeralCounter = 0
    #bestOrder,_,listOfScores = sfl.computeBestOrderEnum(I_array, r, alph, Def, G_circ, eMethod=typeEff)
    bestOrder,_,meanVect, StdData,_ = sfl.computeBestOrderEnum(I_array, r, alph, Def, G_circ,eMethod=typeEff)
    #print('Enumeration, Number of Minimizations solved : ', NumeralCounter)
    numCount =  sfl.NumeralCounter
    totEffB,_ ,_ = sfl.plotTrial(Def, I_dict, bestOrder, G_circ, alph, r, plotFlag=0, axisSz=[-17,17,-5,17],effMethod=typeEff)
 
    #print('Best Order : ',bestOrder)
    #print('Best Score : ',totEffB)
    #print('list of Scores : ',listOfScores)
    tupleOut = (sfl.NumeralCounter, bestOrder, totEffB, I_array, meanVect, StdData)
    data.append(tupleOut)
    #print(tupleOut)

with open(new_path, 'wb') as file:
        np.save(file, data)
        

