import time
NumeralCounter = 0
import numpy as np
import matplotlib
from scipy.optimize import minimize
from scipy import optimize
from scipy.special import perm

from sklearn.metrics import silhouette_score, silhouette_samples
import sklearn.metrics as skm
from scipy.special import factorial

from sklearn.cluster import KMeans

import itertools

import matplotlib.pyplot as plt
#matplotlib.pygui(true)
print(matplotlib.is_interactive())

import platform
print(platform.python_version(), "Cool")
import zeppNumLib


import sdmiFuncLib as sfl
import os
#import sdmiFuncLib

# r =0
# alph = 5
# Def = [0, 0]
# G_circ = [0, -8,  8]

# NoInv = 6
# NoSamp = 3
# dataSetName = "/Datasets/Dataset_6I_v1.npy"
# typeEff = 0
# numberOfIter = 0
# Error = []
# data = []



# trialNo = 32
# cur_path = os.path.dirname(__file__)

# filename = cur_path +dataSetName 

# fig, axs = plt.subplots(1, 2,figsize=(10,15) )
# BestOrder,BestScore, Iarr, NumCount, meanVect, StdData = sfl.loadTrialData(filename, trialNo)
# I_dict, I_list = sfl.createInvDict(Iarr)

# totEffB1, P_star1, TT = sfl.plotTrial(Def, I_dict, BestOrder, G_circ, alph, r, plotFlag=1,axisSz=[-17,17,-10,25],effMethod=typeEff, plt=axs[0])

# def kmeanClustGen(I_array):
#     metric = []
#     models = []
#     for i in range(1,len(I_array)-1):
#         kmeans = KMeans(n_clusters=i+1).fit(I_array)
#         models.append(kmeans)
#         sample_silhouette_values = silhouette_samples(I_array, kmeans.labels_)
#         nonZero = np.sum(np.ceil(list(sample_silhouette_values)))
#         metric.append(np.sum((sample_silhouette_values))/nonZero )
        

#     best = np.argmax(metric)

#     return metric, models[best], best+2



# def adaptiveClusteringOrder (I_array, Def, G_circ, alph, r,typeEff=0, reInit = False, prevClust = 0):

#     #Define Dictionary and List of Invaders
#     I_dict, I_list = sfl.createInvDict(I_array)

#     #Find best clustering combo
#     metric, models, best = kmeanClustGen(I_array)


#     #Extract centroid from cluster model
#     centroid = [c for c in models.cluster_centers_]
#     labels = [c for c in models.labels_]
    
#     # Handle reinit
#     if(reInit):
#         kmeans = KMeans(n_clusters=prevClust+1).fit(I_array)
#         #Extract centroid from cluster model
#         centroid = [c for c in kmeans.cluster_centers_]
#         labels = [c for c in kmeans.labels_]

#     #Create Dictionary of Clusters  
#     clusters = []
#     cluster_sz = np.size(centroid,0)
#     num = np.arange(cluster_sz)
#     Clust_list = []
#     Clust_dict = {}
#     Clust_Cent = centroid 
#     for i, num in enumerate(num):
#         Clust_list.append('C' + str(num))
#         Clust_dict[Clust_list[i]] = []
#         for k, l in enumerate(labels):
#             if l == i:
#                 Clust_dict[Clust_list[i]].append([I_list[k]])

#     # Clust_dict contains a list of invaders in each cluster
    
#     #Generated best order of cluster centroids
  
    
#     bestOrder, P_star, meanVect, StdData, T_cl = sfl.computeBestOrderEnum(Clust_Cent, r, alph, Def, G_circ,eMethod=typeEff)
#     #convert from I -> C

   
#     orderedClusters = []
#     for iv in bestOrder:
#         #print(iv)
#         orderedClusters.append('C' + str(iv[1]))
    
#     print("Clust_dict")
#     print(Clust_dict)
#     #Now, the orders within clusters are determined


#     #First an positional array is generated for the cluster
    
#     listOfInvClust = []
#     Start = Def
#     dist = 0
#     T = 0
    
#     last_clust = best - 1
    
#     predictedOrder = []

#     for i, clust in enumerate(orderedClusters):
#         OptomizedCluster = []
#         invInClust = Clust_dict[clust]
    
#         Iarr = []
#         invInClust_clean = []
#         for inv in invInClust:
#             invInClust_clean.append(inv[0])
#             Iarr.append(I_dict[inv[0]])
        
#         if i < last_clust:
#             C = Clust_Cent[i+1]
#             Iarr.append(C)
           



#         if len(invInClust_clean) > 1:
#             #print(invInClust_clean)
#             bestOrder_raw, P_star, meanVect, StdData, T = sfl.computeBestOrderEnum(Iarr, r, alph, Start, G_circ, dist = T, eMethod=typeEff)   
            
#             if i < last_clust:
#                 NoOfVirt = len(bestOrder_raw) - 1
#                 title = 'I' + str(NoOfVirt)
#                 #print("evil", title )
#                 bestOrder_raw.remove(title)

#             # print("trouble0", invInClust_clean)
#             # print("trouble1",  bestOrder_raw)
#             # print("trouble2",  i)
#             # print("trouble3",  last_clust)
#             new_order = [np.int8(num[1]) for num in bestOrder_raw]
#             # print("trouble4",  new_order)
#             bestOrder = [invInClust_clean[i] for i in new_order]
#             Start = P_star[-1:][0]
#             for inv in bestOrder:
#                 predictedOrder.append(inv)


#         else:
            
#             bestOrder = invInClust_clean 
#             predictedOrder.append(bestOrder[0])
#             totEffB, P_star, T = sfl.plotTrial(Start, I_dict, BestOrder, G_circ, alph, r, plotFlag=0,axisSz=[-17,17,-10,25],effMethod=typeEff,  T=0 )
#             Start = P_star[-1:][0]


#         #print("cool", bestOrder)


#         listOfInvClust.append(Iarr)




#         #print("Unit", Iarr)

    
#     print(P_star)
#     totEffB1, P_star, TT = sfl.plotTrial(Def, I_dict, predictedOrder, G_circ, alph, r, plotFlag=0,axisSz=[-17,17,-10,25],effMethod=typeEff, plt=axs[1])
#     K = sfl.numInTarget(P_star, G_circ, predictedOrder, I_dict)

#     # if K > 0 and (prevClust+1) < len(I_list) and reInit == False:
#     #     prevClust = len(Clust_list)
#     #     predictedOrder = adaptiveClusteringOrder (I_array, Def, G_circ, alph, r,typeEff=0, reInit = True, prevClust = prevClust )
    
#     return predictedOrder




r =0
alph = 5
Def = [0, 0]
G_circ = [0, -8,  8]

NoInv = 6
NoSamp = 3
dataSetName = "/Datasets/Dataset_4I_v1.npy"
typeEff = 0
numberOfIter = 0
Error = []
data = []

iteration = []
fig, axs = plt.subplots(1, 2)


trialNo = 6
trialNo = 2
trialNo = 19
cur_path = os.path.dirname(__file__)

filename = cur_path +dataSetName 

BestOrder,BestScore, Iarr, NumCount, meanVect, StdData = sfl.loadTrialData(filename, trialNo)
I_dict, I_list = sfl.createInvDict(Iarr)
totEffB1, P_star1, TT = sfl.plotTrial(Def, I_dict, BestOrder, G_circ, alph, r, plotFlag=1,axisSz=[-17,17,-10,25],effMethod=typeEff, plt=axs[0])

enumScore = sfl.numInTarget(P_star1,G_circ, BestOrder, I_dict)
#print("EnumScore:", enumScore)
print("Number of Iter: ", NumCount )


sfl.NumeralCounter = 0



out = sfl.adaptiveClusteringOrder (Iarr, Def, G_circ, alph, r,InitMode=True)

#print("Function Output:")
#print(out)
totEffB1, P_star, TT = sfl.plotTrial(Def, I_dict, out, G_circ, alph, r, plotFlag=1,axisSz=[-17,17,-10,25],effMethod=typeEff, plt=axs[1])
predScore = sfl.numInTarget(P_star,G_circ, out, I_dict)
Error.append(predScore - enumScore)
iteration.append(sfl.NumeralCounter )
axs[0].title.set_text('A. Exact Solution (Auxiliary Objective I)')
axs[1].title.set_text('B. Approximate Solution')
axs[0].legend(fontsize='x-small')
axs[0].set_xticks([])
axs[0].set_yticks([])
axs[1].set_xticks([])
axs[1].set_yticks([])
axs[0].axis([-17,17,-10,32])
axs[1].axis([-17,17,-10,32])
#print("predScore:", predScore)
print("Number of Iter: ", sfl.NumeralCounter )
print("Number that got through: ", predScore - enumScore)
#print("Norm of Iter: ", 6*factorial(6))
#print("BestOrder: ", BestOrder)


    # fig1, axs1 = plt.subplots( )
    # axs1.plot(Error)
    # axs1.set_xlim([0,45])
    # axs1.set_ylim(-0.1,1.1)


    # fig2, axs2 = plt.subplots( )
    # axs2.plot(iteration / ( 6*factorial(6)) )
    # axs[1].set_xlim([0,45])
    # axs[1].set_ylim(-0.1,1.1)

fig1, axs1 = plt.subplots( )
totEffB1, P_star1, TT = sfl.plotTrial(Def, I_dict, BestOrder, G_circ, alph, r, plotFlag=1,axisSz=[-17,17,-10,25],effMethod=typeEff, plt=axs1 )

plt.xlabel("X-Pose")
plt.ylabel("Y-Pose")
axs1.set_title('Solution to 4-Invader SDMI Problem')
axs1.legend(fontsize='x-small')
# Setting the values for all axes.
#plt.setp(axs, xlim=custom_xlim, ylim=custom_ylim)

#sfl.plotEnumerations(Iarr, r, alph, Def, G_circ, dist=0, eMethod = 0 )
fig, axe2 = plt.subplots(1,2)
ax2= axe2[0]
#ax2.scatter(Def[0], Def[1], c='y', s=30, marker="^")
theta = np.linspace(-np.pi, np.pi, 300)
X_circ = G_circ[0] + G_circ[2]*np.cos(theta)
Y_circ = G_circ[1] + G_circ[2]*np.sin(theta)
ax2.plot(X_circ, Y_circ,c='b', label='Target Region')
ax2.scatter(Def[0], Def[1], c='y', s=70, marker="^", label='Defender')
I_pos =  np.zeros([len(I_list),2])
for i, Invader in enumerate(I_list):
    I_pos[i,:] = I_dict[Invader]
    ax2.scatter( I_pos[i,0], I_pos[i,1],c='r',s=60 )

ax2.scatter( np.nan , np.nan, c='r',s=60,label='Invader' )
ax2.legend()
ax2.axis([-17,17,-10,32])

ax2.set_xlabel(r'x-position')
ax2.set_ylabel(r'y-position')
ax2.set_xticks([])
ax2.set_yticks([])
ax2.set_title("A. Initialized SDMI Game (6 Invader)")

sfl.plotEnumerations(Iarr, r, alph, Def, G_circ, dist=0, eMethod = 1, plt=axe2[1] )
axe2[1].set_title('B. Distribution of $\mathbb{n}$ Across The Solution Space')
plt.show()