#ifdef EIGEN_MPL2_ONLY
#error Including non-MPL2 code in EIGEN_MPL2_ONLY mode
#endif
