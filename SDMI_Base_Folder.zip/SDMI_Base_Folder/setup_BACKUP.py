from distutils.core import setup, Extension
import os
pth = os.path.dirname(os.path.abspath(__file__))

module = Extension("zeppNumLib2", sources=["zeppNumLib_src.cpp"],include_dirs=[ (pth+'/Eigen')])

setup(name="zeppNumLib2_Pkg", version='2.0', description='Accelerated Numeric Operations',
ext_modules = [module])
