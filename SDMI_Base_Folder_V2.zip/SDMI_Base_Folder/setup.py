from setuptools import setup, Extension
import os
pth = os.path.dirname(os.path.abspath(__file__))
print('!!!!!!')
module = Extension("zeppNumLib2", sources=["zeppNumLib_src.cpp"],include_dirs=[ (pth+'/Eigen')])
#module2 = py_modules("sdmiFuncLib", sources=["sdmiFuncLib"])


setup(name="zeppNumLib2_Pkg", version='2.0', description='Accelerated Numeric Operations',


    ext_modules = [module],
    py_modules = ['sdmiFuncLib'])

print("Successfull!!")
