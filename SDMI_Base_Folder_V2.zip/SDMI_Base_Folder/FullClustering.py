import time
NumeralCounter = 0
import numpy as np
import matplotlib
from scipy.optimize import minimize
from scipy import optimize
from scipy.special import perm

from sklearn.metrics import silhouette_score, silhouette_samples
import sklearn.metrics as skm
from scipy.special import factorial

from sklearn.cluster import KMeans

import itertools

import matplotlib.pyplot as plt
#matplotlib.pygui(true)
print(matplotlib.is_interactive())

import platform
print(platform.python_version(), "Cool")
import zeppNumLib2


import sdmiFuncLib as sfl
import os

r =0
alph = 5
Def = [0, 0]
G_circ = [0, -8,  8]

NoInv = 6
NoSamp = 3
dataSetName = "/Datasets/Dataset_4I_v1.npy"
typeEff = 0
numberOfIter = 0
Error = []
data = []

iteration = []
fig, axs = plt.subplots(1, 2)


trialNo = 6
trialNo = 2
trialNo = 19
cur_path = os.path.dirname(os.path.abspath(__file__))

filename = cur_path +dataSetName 

BestOrder,BestScore, Iarr, NumCount, meanVect, StdData = sfl.loadTrialData(filename, trialNo)
I_dict, I_list = sfl.createInvDict(Iarr)
totEffB1, P_star1, TT = sfl.plotTrial(Def, I_dict, BestOrder, G_circ, alph, r, plotFlag=1,axisSz=[-17,17,-10,25],effMethod=typeEff, plt=axs[0])

enumScore = sfl.numInTarget(P_star1,G_circ, BestOrder, I_dict)
#print("EnumScore:", enumScore)
print("Number of Iter: ", NumCount )


sfl.NumeralCounter = 0



out = sfl.adaptiveClusteringOrder (Iarr, Def, G_circ, alph, r,InitMode=True)

#print("Function Output:")
#print(out)
totEffB1, P_star, TT = sfl.plotTrial(Def, I_dict, out, G_circ, alph, r, plotFlag=1,axisSz=[-17,17,-10,25],effMethod=typeEff, plt=axs[1])
predScore = sfl.numInTarget(P_star,G_circ, out, I_dict)
Error.append(predScore - enumScore)
iteration.append(sfl.NumeralCounter )
axs[0].title.set_text('A. Exact Solution (Auxiliary Objective I)')
axs[1].title.set_text('B. Approximate Solution')
axs[0].legend(fontsize='x-small')
axs[0].set_xticks([])
axs[0].set_yticks([])
axs[1].set_xticks([])
axs[1].set_yticks([])
axs[0].axis([-17,17,-10,32])
axs[1].axis([-17,17,-10,32])
#print("predScore:", predScore)
print("Number of Iter: ", sfl.NumeralCounter )
print("Number that got through: ", predScore - enumScore)
#print("Norm of Iter: ", 6*factorial(6))
#print("BestOrder: ", BestOrder)


    # fig1, axs1 = plt.subplots( )
    # axs1.plot(Error)
    # axs1.set_xlim([0,45])
    # axs1.set_ylim(-0.1,1.1)


    # fig2, axs2 = plt.subplots( )
    # axs2.plot(iteration / ( 6*factorial(6)) )
    # axs[1].set_xlim([0,45])
    # axs[1].set_ylim(-0.1,1.1)

fig1, axs1 = plt.subplots( )
totEffB1, P_star1, TT = sfl.plotTrial(Def, I_dict, BestOrder, G_circ, alph, r, plotFlag=1,axisSz=[-17,17,-10,25],effMethod=typeEff, plt=axs1 )

plt.xlabel("X-Pose")
plt.ylabel("Y-Pose")
axs1.set_title('Solution to 4-Invader SDMI Problem')
axs1.legend(fontsize='x-small')
# Setting the values for all axes.
#plt.setp(axs, xlim=custom_xlim, ylim=custom_ylim)

#sfl.plotEnumerations(Iarr, r, alph, Def, G_circ, dist=0, eMethod = 0 )
fig, axe2 = plt.subplots(1,2)
ax2= axe2[0]
#ax2.scatter(Def[0], Def[1], c='y', s=30, marker="^")
theta = np.linspace(-np.pi, np.pi, 300)
X_circ = G_circ[0] + G_circ[2]*np.cos(theta)
Y_circ = G_circ[1] + G_circ[2]*np.sin(theta)
ax2.plot(X_circ, Y_circ,c='b', label='Target Region')
ax2.scatter(Def[0], Def[1], c='y', s=70, marker="^", label='Defender')
I_pos =  np.zeros([len(I_list),2])
for i, Invader in enumerate(I_list):
    I_pos[i,:] = I_dict[Invader]
    ax2.scatter( I_pos[i,0], I_pos[i,1],c='r',s=60 )

ax2.scatter( np.nan , np.nan, c='r',s=60,label='Invader' )
ax2.legend()
ax2.axis([-17,17,-10,32])

ax2.set_xlabel(r'x-position')
ax2.set_ylabel(r'y-position')
ax2.set_xticks([])
ax2.set_yticks([])
ax2.set_title("A. Initialized SDMI Game (6 Invader)")

sfl.plotEnumerations(Iarr, r, alph, Def, G_circ, dist=0, eMethod = 1, plt=axe2[1] )
axe2[1].set_title('B. Distribution of $\mathbb{n}$ Across The Solution Space')
plt.show()